#!/usr/bin/env python3
"""
Offline OCR Desktop App — Batch Folder Processor
English only. No internet required. No Gradio.
"""

import os
import sys
import io
import cv2
import shutil
import queue
import threading
import traceback
import subprocess
from pathlib import Path
from tkinter import (
    Tk, Frame, Label, Button, Entry, Checkbutton,
    filedialog, messagebox, scrolledtext, StringVar, BooleanVar
)
from tkinter.ttk import Progressbar, Treeview, Scrollbar

import numpy as np
from PIL import Image as PILImage
import ocrmypdf
from ocrmypdf.exceptions import ExitCodeException

SUPPORTED_EXTS = (".pdf", ".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp")


def check_dependencies():
    """Check Tesseract & Ghostscript. Return list of missing tools."""
    missing = []
    # Tesseract
    try:
        subprocess.run(
            ["tesseract", "--version"],
            capture_output=True, check=True, timeout=5
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        missing.append("Tesseract OCR")
    # Ghostscript
    found_gs = False
    for cmd in ("gswin64c", "gswin32c", "gs"):
        try:
            subprocess.run(
                [cmd, "--version"],
                capture_output=True, check=True, timeout=5
            )
            found_gs = True
            break
        except (FileNotFoundError, subprocess.CalledProcessError):
            continue
    if not found_gs:
        missing.append("Ghostscript")
    return missing


def enhance_image(input_path: str, output_path: str):
    img = cv2.imread(input_path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Cannot read image: {input_path}")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    denoised = cv2.fastNlMeansDenoising(gray, h=10)
    binary = cv2.adaptiveThreshold(
        denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, blockSize=15, C=5
    )
    kernel = np.array([[-1, -1, -1],
                       [-1,  9, -1],
                       [-1, -1, -1]])
    sharpened = cv2.filter2D(binary, -1, kernel)
    cv2.imwrite(output_path, sharpened)


def get_image_dpi(image_path: str) -> int:
    try:
        with PILImage.open(image_path) as img:
            dpi = img.info.get("dpi")
            if not dpi or dpi == (0, 0) or dpi[0] < 10:
                return 300
            return int(dpi[0])
    except Exception:
        return 300


def extract_preview(pdf_path: str, max_chars: int = 400) -> str:
    try:
        txt = subprocess.check_output(
            ["pdftotext", pdf_path, "-", "-l", "1"],
            text=True, stderr=subprocess.STDOUT, timeout=15
        ).strip()
        return txt[:max_chars] + ("..." if len(txt) > max_chars else "")
    except Exception as e:
        return f"(Preview unavailable)"


class OCRWorker(threading.Thread):
    def __init__(self, app):
        super().__init__(daemon=True)
        self.app = app
        self.stop_event = threading.Event()

    def log(self, msg: str):
        self.app.queue.put(("log", msg))

    def progress(self, value: int):
        self.app.queue.put(("progress", value))

    def file_done(self, filename: str, status: str, out_path: str = "", preview: str = ""):
        self.app.queue.put(("file_done", filename, status, out_path, preview))

    def run(self):
        input_dir = Path(self.app.input_var.get())
        output_dir = Path(self.app.output_var.get())
        enhance = self.app.enhance_var.get()
        deskew = self.app.deskew_var.get()

        files = sorted([
            f for f in input_dir.iterdir()
            if f.is_file() and f.suffix.lower() in SUPPORTED_EXTS
        ])
        total = len(files)

        if total == 0:
            self.log("⚠️ No supported files found in input folder.")
            self.app.queue.put(("done",))
            return

        self.log(f"📁 Found {total} file(s) to process.")
        output_dir.mkdir(parents=True, exist_ok=True)

        for idx, file_path in enumerate(files, 1):
            if self.stop_event.is_set():
                self.log("🛑 Stopped by user.")
                break

            self.log(f"\n▶ [{idx}/{total}] {file_path.name}")
            tmp_dir = Path(output_dir) / f"_tmp_{file_path.stem}"
            tmp_dir.mkdir(exist_ok=True)

            try:
                input_path = str(file_path)
                ext = file_path.suffix.lower()

                # Optional enhancement
                if enhance and ext in (".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp"):
                    enhanced = tmp_dir / "enhanced.png"
                    enhance_image(input_path, str(enhanced))
                    input_path = str(enhanced)
                    self.log("   ✓ Image enhanced")

                # DPI fix
                image_dpi = None
                if ext in (".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp"):
                    image_dpi = get_image_dpi(input_path)
                    self.log(f"   ✓ DPI set to {image_dpi}")

                out_pdf = output_dir / f"{file_path.stem}_OCR.pdf"
                log_stream = io.StringIO()

                ocrmypdf.ocr(
                    input_path,
                    str(out_pdf),
                    language="eng",
                    deskew=deskew,
                    skip_text=True,
                    output_type="pdf",
                    image_dpi=image_dpi,
                    verbose=True,
                    progress_bar=False,
                    stderr=log_stream,
                )

                preview = extract_preview(str(out_pdf))
                self.file_done(file_path.name, "✅ Success", str(out_pdf), preview)
                self.log(f"   ✓ Saved: {out_pdf.name}")

            except ExitCodeException as e:
                log_content = log_stream.getvalue()
                err = f"Exit code {e.exit_code}: {str(e)}"
                self.file_done(file_path.name, "❌ Failed", "", err)
                self.log(f"   ✗ OCRmyPDF error: {err}")
                if log_content:
                    self.log(f"   Log tail:\n{log_content[-600:]}")

            except Exception as e:
                self.file_done(file_path.name, "❌ Failed", "", str(e))
                self.log(f"   ✗ Error: {str(e)}")

            finally:
                if tmp_dir.exists():
                    shutil.rmtree(tmp_dir, ignore_errors=True)
                self.progress(int((idx / total) * 100))

        self.log(f"\n🏁 Batch complete.\n   Output folder: {output_dir}")
        self.app.queue.put(("done",))


class OCRApp:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title("Offline OCR Batch Tool — English Only")
        self.root.geometry("960x760")
        self.root.minsize(860, 650)

        self.queue = queue.Queue()
        self.worker = None

        self.input_var = StringVar()
        self.output_var = StringVar()
        self.enhance_var = BooleanVar(value=False)
        self.deskew_var = BooleanVar(value=True)

        self._build_ui()
        self._poll_queue()
        self._check_deps()

    def _check_deps(self):
        missing = check_dependencies()
        if missing:
            msg = (
                "Missing system dependencies (install these on your PC):\n\n"
                + "\n".join(f"  • {m}" for m in missing)
                + "\n\nThe app will open, but OCR will fail until they are installed.\n\n"
                "Download links:\n"
                "• Tesseract OCR: github.com/UB-Mannheim/tesseract/wiki\n"
                "• Ghostscript: www.ghostscript.com/download/gsdnld.html\n\n"
                "Install both, add to PATH, then restart this app."
            )
            messagebox.showwarning("Dependencies Missing", msg)

    def _build_ui(self):
        # Folder selection
        top = Frame(self.root, padx=14, pady=14)
        top.pack(fill="x")

        Label(top, text="Input Folder:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", pady=6)
        Entry(top, textvariable=self.input_var, width=62, font=("Segoe UI", 9)).grid(row=0, column=1, padx=6, pady=6)
        Button(top, text="Browse…", command=self._browse_input, width=10).grid(row=0, column=2, pady=6)

        Label(top, text="Output Folder:", font=("Segoe UI", 10, "bold")).grid(row=1, column=0, sticky="w", pady=6)
        Entry(top, textvariable=self.output_var, width=62, font=("Segoe UI", 9)).grid(row=1, column=1, padx=6, pady=6)
        Button(top, text="Browse…", command=self._browse_output, width=10).grid(row=1, column=2, pady=6)

        # Options
        opts = Frame(self.root, padx=14, pady=4)
        opts.pack(fill="x")
        Checkbutton(opts, text="Enhance images (denoise + sharpen)", variable=self.enhance_var, font=("Segoe UI", 9)).pack(side="left", padx=6)
        Checkbutton(opts, text="Deskew (straighten pages)", variable=self.deskew_var, font=("Segoe UI", 9)).pack(side="left", padx=6)

        # Action buttons
        btn = Frame(self.root, padx=14, pady=6)
        btn.pack(fill="x")

        self.start_btn = Button(btn, text="▶  Start OCR Batch", bg="#27ae60", fg="white",
                                font=("Segoe UI", 10, "bold"), command=self._start, width=18)
        self.start_btn.pack(side="left", padx=4)

        self.stop_btn = Button(btn, text="⏹  Stop", bg="#c0392b", fg="white",
                               font=("Segoe UI", 10, "bold"), command=self._stop, state="disabled", width=10)
        self.stop_btn.pack(side="left", padx=4)

        Button(btn, text="📂  Open Output Folder", command=self._open_output, width=18).pack(side="left", padx=4)

        # Progress bar
        prog = Frame(self.root, padx=14, pady=4)
        prog.pack(fill="x")
        self.progress = Progressbar(prog, orient="horizontal", mode="determinate")
        self.progress.pack(fill="x", expand=True)

        # Results table
        tree_frame = Frame(self.root, padx=14, pady=6)
        tree_frame.pack(fill="both", expand=True)

        cols = ("Status", "Output File", "Text Preview")
        self.tree = Treeview(tree_frame, columns=cols, show="headings", height=10)
        self.tree.heading("#0", text="Filename")
        self.tree.column("#0", width=190)
        self.tree.heading("Status", text="Status")
        self.tree.column("Status", width=80, anchor="center")
        self.tree.heading("Output File", text="Output File")
        self.tree.column("Output File", width=210)
        self.tree.heading("Text Preview", text="Text Preview")
        self.tree.column("Text Preview", width=320)

        vsb = Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        hsb = Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        self.tree.tag_configure("success", foreground="#27ae60", font=("Segoe UI", 9, "bold"))
        self.tree.tag_configure("fail", foreground="#c0392b", font=("Segoe UI", 9, "bold"))

        # Log console
        log_frame = Frame(self.root, padx=14, pady=6)
        log_frame.pack(fill="both", expand=True)
        Label(log_frame, text="Activity Log:", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.log_box = scrolledtext.ScrolledText(log_frame, wrap="word", font=("Consolas", 9), height=10)
        self.log_box.pack(fill="both", expand=True)

    def _browse_input(self):
        d = filedialog.askdirectory(title="Select Input Folder")
        if d:
            self.input_var.set(d)
            if not self.output_var.get():
                self.output_var.set(os.path.join(d, "OCR_Output"))

    def _browse_output(self):
        d = filedialog.askdirectory(title="Select Output Folder")
        if d:
            self.output_var.set(d)

    def _open_output(self):
        p = self.output_var.get()
        if p and os.path.isdir(p):
            os.startfile(p)
        else:
            messagebox.showwarning("Not Found", "Output folder does not exist yet.")

    def _start(self):
        inp = self.input_var.get().strip()
        out = self.output_var.get().strip()

        if not inp or not os.path.isdir(inp):
            messagebox.showerror("Error", "Please select a valid input folder.")
            return
        if not out:
            messagebox.showerror("Error", "Please specify an output folder.")
            return

        for item in self.tree.get_children():
            self.tree.delete(item)
        self.log_box.delete("1.0", "end")
        self.progress["value"] = 0

        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")

        self.worker = OCRWorker(self)
        self.worker.start()

    def _stop(self):
        if self.worker:
            self.worker.stop_event.set()
            self.log("⏳ Stopping after current file…")

    def _on_done(self):
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.worker = None
        messagebox.showinfo("Complete", "Batch processing finished!")

    def _poll_queue(self):
        try:
            while True:
                msg = self.queue.get_nowait()
                cmd = msg[0]
                if cmd == "log":
                    self._append_log(msg[1])
                elif cmd == "progress":
                    self.progress["value"] = msg[1]
                elif cmd == "file_done":
                    _, fname, status, out_path, preview = msg
                    tag = "success" if "Success" in status else "fail"
                    self.tree.insert("", "end", text=fname,
                                     values=(status, Path(out_path).name if out_path else "", preview),
                                     tags=(tag,))
                elif cmd == "done":
                    self._on_done()
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self._poll_queue)

    def _append_log(self, text: str):
        self.log_box.insert("end", text + "\n")
        self.log_box.see("end")


def main():
    root = Tk()
    OCRApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
