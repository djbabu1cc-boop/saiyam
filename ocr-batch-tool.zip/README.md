# Offline OCR Batch Tool — Windows Desktop App

Double-click the `.exe`, browse for a folder full of scans/PDFs, and get searchable PDFs in a new output folder. Completely offline. English only.

---

## 📱 Build the .EXE from your phone (No PC needed)

Follow these steps on your phone browser:

### Step 1: Create a free GitHub account
- Go to **github.com** on your phone browser
- Tap **Sign up** and create a free account (takes 2 minutes)

### Step 2: Create a new repository
- Tap the **+** icon → **New repository**
- Name it: `ocr-batch-tool`
- Choose **Public**
- Tap **Create repository**

### Step 3: Upload the files from this ZIP
- In your new repo, tap **Add file** → **Upload files**
- Upload **all 3 files** from this ZIP:
  1. `ocr_desktop_app.py`
  2. `requirements.txt`
  3. `.github/workflows/build.yml`
     - *Tip: create folders by typing `.github/workflows/` in the filename box*
- Tap **Commit changes**

### Step 4: Run the build
- Go to the **Actions** tab at the top
- Tap **Build Windows EXE** on the left
- Tap the grey **Run workflow** button → **Run workflow**
- Wait 3–4 minutes (you can close your phone; GitHub does it in the cloud)

### Step 5: Download your .exe
- Once the green checkmark appears, tap the completed run
- Scroll down to **Artifacts**
- Tap **OCR_Batch_Tool_Windows** to download a ZIP
- The `.exe` is inside that ZIP

---

## 🖥️ Run on your Windows PC

Before using the `.exe`, install these two free tools **once**:

1. **Tesseract OCR** (the actual OCR engine)
   - Download: https://github.com/UB-Mannheim/tesseract/wiki
   - Install the **64-bit Windows** version
   - **Important:** During install, check the box **"Add to PATH"**

2. **Ghostscript** (required for PDF processing)
   - Download: https://www.ghostscript.com/download/gsdnld.html
   - Install the **64-bit** version
   - **Important:** During install, check the box **"Add to PATH"**

> If you already installed these for the Colab version, you are good to go.

---

## 🚀 How to use the app

1. Double-click `OCR_Batch_Tool.exe`
2. Click **Browse** next to **Input Folder** — pick the folder with your scanned PDFs/images
3. Output folder auto-fills as `OCR_Output` inside it (or pick your own)
4. Check **Enhance images** if your scans are blurry or noisy
5. Click **Start OCR Batch**
6. Watch the progress bar and results table
7. Click **Open Output Folder** to collect your new searchable PDFs

---

## ✅ Features

| Feature | Detail |
|---------|--------|
| **Folder batch** | Processes every PDF/image in a folder at once |
| **Formats** | PDF, JPG, JPEG, PNG, TIFF, TIF, BMP |
| **English only** | Hardcoded to English (Hindi removed) |
| **DPI auto-fix** | Missing DPI defaults to 300 automatically |
| **Enhance** | Optional denoise + adaptive threshold + sharpen |
| **Deskew** | Auto-straightens crooked scans |
| **Offline** | Zero internet after setup |
| **Error logs** | Full per-file error reporting in the console |
| **Text preview** | See extracted text from page 1 of each result |
| **Stop button** | Gracefully stop mid-batch |

---

## 🛠️ Troubleshooting

**"Tesseract not found" warning**
→ Reinstall Tesseract and make sure **"Add to PATH"** is checked.

**"Ghostscript not found" warning**
→ Reinstall Ghostscript and make sure **"Add to PATH"** is checked.

**OCR fails on a specific file**
→ Check the Activity Log for the exact error. Common fixes:
- Corrupted PDF: try opening and re-saving it
- Very low quality scan: check **Enhance images**
- Missing text layer already: the file may already be searchable

---

## 📦 File list

- `ocr_desktop_app.py` — Main application source code
- `requirements.txt` — Python dependencies for the builder
- `.github/workflows/build.yml` — GitHub Actions auto-build script
- `README.md` — This file
